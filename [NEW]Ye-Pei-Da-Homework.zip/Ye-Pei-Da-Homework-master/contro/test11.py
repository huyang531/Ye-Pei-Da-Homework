from os import system

x1 = float(input("1："))
x2 = float(input("2："))
x3 = float(input("3："))
x4 = float(input("4："))
x5 = float(input("5："))
system("rostopic pub -1 /mrm/joint1_position_controller/command std_msgs/Float64 \"data: {y1}\"".format(y1=x1))
system("rostopic pub -1 /mrm/joint2_position_controller/command std_msgs/Float64 \"data: {y2}\"".format(y2=x2))
system("rostopic pub -1 /mrm/joint3_position_controller/command std_msgs/Float64 \"data: {y3}\"".format(y3=x3))
system("rostopic pub -1 /mrm/joint4_position_controller/command std_msgs/Float64 \"data: {y4}\"".format(y4=x4))
system("rostopic pub -1 /mrm/joint5_position_controller/command std_msgs/Float64 \"data: {y5}\"".format(y5=x5))
